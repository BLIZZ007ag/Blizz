# Blizz — phone-only cloud build

This project includes a GitHub Actions workflow so you can build Blizz from a phone without installing Android Studio.

## On your phone
1. Create/sign in to a GitHub account.
2. Create a new repository named `Blizz`.
3. Upload the contents of this project ZIP to the repository (keep the folder structure).
4. Open the repository's **Actions** tab.
5. Select **Build Blizz Android** and tap **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed workflow run and download the **blizz-builds** artifact.

The artifact contains:
- a debug APK for testing on your phone;
- a release AAB for Google Play preparation.

## Important
The release AAB is not signed for Play App Signing yet. Before publishing to Google Play, create/configure a proper release signing key and complete Play Console's app-signing setup.

During development, use Google's test ad units. Replace test IDs with your live AdMob IDs only for the release build after testing.
