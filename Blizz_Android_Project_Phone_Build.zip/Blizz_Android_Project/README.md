# Blizz Android Project

Blizz is a WebView-based trivia/music game with 1,000 questions.

## AdMob
- AdMob App ID: ca-app-pub-2139922276822629~9353052855
- Banner Ad Unit ID: ca-app-pub-2139922276822629/1582374044

The banner is configured at the bottom of the game screen.

IMPORTANT: During development/testing, use Google's official test ad unit ID instead of a live ad unit. Replace the test ID with your live Banner Ad Unit ID only for release/testing on production builds, following AdMob policies.

## Build
Open this folder in Android Studio, let Gradle sync, then build/run the app.


## Phone-only build
See `PHONE_BUILD_GUIDE.md`. A GitHub Actions workflow is included at `.github/workflows/build.yml` so the project can be built from a phone.
